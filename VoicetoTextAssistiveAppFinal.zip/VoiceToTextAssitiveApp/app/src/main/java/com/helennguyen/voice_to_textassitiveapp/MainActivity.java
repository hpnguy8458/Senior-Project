package com.helennguyen.voice_to_textassitiveapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_SPEECH_INPUT = 1;
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 100;

    private TextView resultText;
    private Button speakEnglish, speakJapanese;
    private EditText englishInput, japaneseInput;
    private Button submitEnglish, submitJapanese;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        resultText = findViewById(R.id.result_text);
        speakEnglish = findViewById(R.id.speak_english);
        speakJapanese = findViewById(R.id.speak_japanese);
        englishInput = findViewById(R.id.english_input);
        japaneseInput = findViewById(R.id.japanese_input);
        submitEnglish = findViewById(R.id.submit_english);
        submitJapanese = findViewById(R.id.submit_japanese);


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    REQUEST_RECORD_AUDIO_PERMISSION);
        }


        speakEnglish.setOnClickListener(v -> startSpeechToText(Locale.ENGLISH));
        speakJapanese.setOnClickListener(v -> startSpeechToText(Locale.JAPANESE));


        submitEnglish.setOnClickListener(v -> {
            String typedText = englishInput.getText().toString().trim();
            if (!typedText.isEmpty()) {
                resultText.setText(typedText);
            }
        });

        submitJapanese.setOnClickListener(v -> {
            String typedText = japaneseInput.getText().toString().trim();
            if (!typedText.isEmpty()) {
                resultText.setText(typedText);
            }
        });
    }

    private void startSpeechToText(Locale language) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now...");

        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
        } catch (Exception e) {
            resultText.setText("Speech recognition not supported on this device.");
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_SPEECH_INPUT && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (result != null && result.size() > 0) {
                resultText.setText(result.get(0));
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION) {
            if (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                resultText.setText("Permission to use the microphone is required.");
            }
        }
    }
}